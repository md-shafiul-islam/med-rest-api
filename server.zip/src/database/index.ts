import { join } from "path";
import { DataSourceOptions } from "typeorm";

export const dbConnectionOption = (): DataSourceOptions => {
  // console.log("__dirname, ", __dirname + "/../model/*{.js,.ts}");
  return {
    type: "mysql",
    host: "localhost",
    port: 3306,
    username: "mdi_YYmdLC8P6aMChcae",
    password: "01725^*^)@(Sa",
    database: "medieco_es",
    logging: false,
    synchronize: true,
    entities: [join(__dirname, "..", "model", "*{.js,.ts}")],
  };
};
